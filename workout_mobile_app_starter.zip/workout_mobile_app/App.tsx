import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';
import { DashboardScreen } from './src/screens/DashboardScreen';
import { PlanScreen } from './src/screens/PlanScreen';
import { LogWorkoutScreen } from './src/screens/LogWorkoutScreen';
import { WeeklyCheckInScreen } from './src/screens/WeeklyCheckInScreen';
import { ReferenceScreen } from './src/screens/ReferenceScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="auto" />
      <Tab.Navigator screenOptions={{ headerTitleStyle: { fontWeight: '800' }, tabBarLabelStyle: { fontWeight: '700' } }}>
        <Tab.Screen name="Dashboard" component={DashboardScreen} />
        <Tab.Screen name="Plan" component={PlanScreen} />
        <Tab.Screen name="Log" component={LogWorkoutScreen} />
        <Tab.Screen name="Check-In" component={WeeklyCheckInScreen} />
        <Tab.Screen name="Reference" component={ReferenceScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
