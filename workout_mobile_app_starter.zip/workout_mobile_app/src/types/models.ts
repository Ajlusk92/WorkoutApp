export type TrainingRow = {
  week: number;
  day: string;
  session: string;
  exercise: string;
  sets: number | string;
  reps: number | string;
  percentTrainingMax?: number | null;
  targetWt: number | string;
  rpeTarget: string;
  progressionRule: string;
  warmUpSets: string;
  notes: string;
};

export type WorkoutSetLog = {
  weight: string;
  reps: string;
  completed: boolean;
};

export type WorkoutLogEntry = {
  id: string;
  date: string;
  week: number;
  day: string;
  exercise: string;
  targetWt: number | string;
  sets: WorkoutSetLog[];
  notes?: string;
};

export type WeeklyCheckIn = {
  week: number;
  actualWeight: string;
  waist: string;
  trainingCalAvg: string;
  restCalAvg: string;
  stepsAvg: string;
  benchE1Rm: string;
  squatE1Rm: string;
  deadliftE1Rm: string;
};
