import AsyncStorage from '@react-native-async-storage/async-storage';
import { WeeklyCheckIn, WorkoutLogEntry } from '../types/models';

const WORKOUT_LOG_KEY = 'workout_log_entries_v1';
const WEEKLY_CHECKIN_KEY = 'weekly_checkins_v1';

export async function loadWorkoutLogs(): Promise<WorkoutLogEntry[]> {
  const raw = await AsyncStorage.getItem(WORKOUT_LOG_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function saveWorkoutLogs(entries: WorkoutLogEntry[]): Promise<void> {
  await AsyncStorage.setItem(WORKOUT_LOG_KEY, JSON.stringify(entries));
}

export async function loadWeeklyCheckIns(): Promise<WeeklyCheckIn[]> {
  const raw = await AsyncStorage.getItem(WEEKLY_CHECKIN_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function saveWeeklyCheckIns(entries: WeeklyCheckIn[]): Promise<void> {
  await AsyncStorage.setItem(WEEKLY_CHECKIN_KEY, JSON.stringify(entries));
}
