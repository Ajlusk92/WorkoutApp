export function estimatedOneRepMax(weight: number, reps: number): number {
  if (!weight || !reps) return 0;
  return Math.round(weight * (1 + reps / 30));
}

export function totalVolume(sets: { weight: string; reps: string }[]): number {
  return sets.reduce((sum, set) => {
    const weight = Number(set.weight) || 0;
    const reps = Number(set.reps) || 0;
    return sum + weight * reps;
  }, 0);
}

export function weeklyLossFlag(loss: number, min = 1, max = 2.5): 'Too Slow' | 'On Pace' | 'Too Fast' {
  if (loss < min) return 'Too Slow';
  if (loss > max) return 'Too Fast';
  return 'On Pace';
}

export function targetWeightForWeek(start: number, goal: number, weeks: number, week: number): number {
  return Math.round((start - ((start - goal) / (weeks - 1)) * (week - 1)) * 10) / 10;
}
