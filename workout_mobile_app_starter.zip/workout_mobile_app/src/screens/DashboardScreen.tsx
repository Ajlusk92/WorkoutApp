import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import program from '../data/workoutProgram.json';
import { Card } from '../components/Card';
import { loadWeeklyCheckIns, loadWorkoutLogs } from '../utils/storage';
import { targetWeightForWeek, totalVolume } from '../utils/calculations';

export function DashboardScreen() {
  const [latestWeight, setLatestWeight] = useState<string>('Not logged');
  const [loggedSessions, setLoggedSessions] = useState(0);
  const [volume, setVolume] = useState(0);

  useEffect(() => {
    const load = async () => {
      const checks = await loadWeeklyCheckIns();
      const logs = await loadWorkoutLogs();
      const latest = [...checks].reverse().find(c => c.actualWeight);
      setLatestWeight(latest?.actualWeight ?? 'Not logged');
      setLoggedSessions(logs.length);
      setVolume(logs.reduce((sum, entry) => sum + totalVolume(entry.sets), 0));
    };
    load();
  }, []);

  const setup = program.setup as Record<string, number>;
  const currentWeek = 1;
  const target = targetWeightForWeek(setup.start_weight, setup.goal_weight, setup.program_weeks, currentWeek);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>{program.meta.title}</Text>
      <Text style={styles.subtitle}>{program.meta.subtitle}</Text>

      <View style={styles.grid}>
        <Card><Text style={styles.label}>Start</Text><Text style={styles.metric}>{setup.start_weight} lb</Text></Card>
        <Card><Text style={styles.label}>Goal</Text><Text style={styles.metric}>{setup.goal_weight} lb</Text></Card>
        <Card><Text style={styles.label}>Week 1 Target</Text><Text style={styles.metric}>{target} lb</Text></Card>
        <Card><Text style={styles.label}>Latest Weight</Text><Text style={styles.metric}>{latestWeight}</Text></Card>
      </View>

      <Card>
        <Text style={styles.sectionTitle}>Training Summary</Text>
        <Text style={styles.body}>Logged sessions: {loggedSessions}</Text>
        <Text style={styles.body}>Logged volume: {volume.toLocaleString()} lb</Text>
        <Text style={styles.body}>Minimum steps: {setup.minimum_steps?.toLocaleString()} / day</Text>
        <Text style={styles.body}>Target steps: {setup.target_steps?.toLocaleString()} / day</Text>
      </Card>

      <Card>
        <Text style={styles.sectionTitle}>Current Lifts</Text>
        {program.lifts.map(lift => (
          <Text key={lift.lift} style={styles.body}>{lift.lift}: {lift.currentOneRepMax} lb 1RM / {lift.trainingMax} lb TM</Text>
        ))}
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f3f4f6' },
  content: { padding: 16 },
  title: { fontSize: 26, fontWeight: '800', marginBottom: 4 },
  subtitle: { color: '#555', marginBottom: 16 },
  grid: { gap: 0 },
  label: { color: '#666', marginBottom: 6 },
  metric: { fontSize: 24, fontWeight: '800' },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 10 },
  body: { fontSize: 15, marginBottom: 6 },
});
