import React from 'react';
import { ScrollView, StyleSheet, Text } from 'react-native';
import program from '../data/workoutProgram.json';
import { Card } from '../components/Card';

export function ReferenceScreen() {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Nutrition</Text>
      {program.nutritionPlan.map((row: any) => (
        <Card key={`nutrition-${row.week}`}>
          <Text style={styles.heading}>Week {row.week}: {row.phase}</Text>
          <Text>Training: {row.trainingDayCalories} cal • Rest: {row.restDayCalories} cal</Text>
          <Text>Protein {row.proteinG}g • Fat {row.fatG}g • Training carbs {row.trainingCarbsG}g</Text>
        </Card>
      ))}
      <Text style={styles.title}>Mobility</Text>
      {program.mobility.map((row: any) => <Card key={row.drill}><Text style={styles.heading}>{row.drill}</Text><Text>{row.dose}</Text><Text>{row.purpose}</Text></Card>)}
      <Text style={styles.title}>Progression Rules</Text>
      {program.progressionRules.map((row: any) => <Card key={row.situation}><Text style={styles.heading}>{row.situation}</Text><Text>{row.coachAction}</Text></Card>)}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f3f4f6' },
  content: { padding: 16 },
  title: { fontSize: 22, fontWeight: '800', marginBottom: 12, marginTop: 8 },
  heading: { fontWeight: '800', marginBottom: 6, fontSize: 16 },
});
