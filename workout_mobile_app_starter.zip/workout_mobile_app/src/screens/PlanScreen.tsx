import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import program from '../data/workoutProgram.json';
import { Card } from '../components/Card';
import { TrainingRow } from '../types/models';

const plan = program.trainingPlan as TrainingRow[];

export function PlanScreen() {
  const [week, setWeek] = useState(1);
  const [day, setDay] = useState('Mon');
  const rows = useMemo(() => plan.filter(r => r.week === week && r.day === day), [week, day]);

  return (
    <View style={styles.container}>
      <View style={styles.filters}>
        <FlatList
          horizontal
          data={Array.from({ length: 12 }, (_, i) => i + 1)}
          keyExtractor={item => `week-${item}`}
          renderItem={({ item }) => <Chip label={`W${item}`} selected={item === week} onPress={() => setWeek(item)} />}
          showsHorizontalScrollIndicator={false}
        />
        <View style={styles.days}>{['Mon', 'Wed', 'Fri'].map(d => <Chip key={d} label={d} selected={d === day} onPress={() => setDay(d)} />)}</View>
      </View>

      <FlatList
        data={rows}
        keyExtractor={(item, index) => `${item.week}-${item.day}-${item.exercise}-${index}`}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <Card>
            <Text style={styles.exercise}>{item.exercise}</Text>
            <Text style={styles.detail}>{item.sets} x {item.reps} • Target: {item.targetWt} lb • RPE {item.rpeTarget}</Text>
            <Text style={styles.note}>{item.progressionRule}</Text>
            <Text style={styles.warmup}>Warm-up: {item.warmUpSets}</Text>
          </Card>
        )}
      />
    </View>
  );
}

function Chip({ label, selected, onPress }: { label: string; selected: boolean; onPress: () => void }) {
  return <Pressable onPress={onPress} style={[styles.chip, selected && styles.chipSelected]}><Text style={[styles.chipText, selected && styles.chipTextSelected]}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f3f4f6' },
  filters: { padding: 12, backgroundColor: '#fff' },
  days: { flexDirection: 'row', marginTop: 10 },
  list: { padding: 16 },
  chip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 999, backgroundColor: '#e5e7eb', marginRight: 8 },
  chipSelected: { backgroundColor: '#111827' },
  chipText: { fontWeight: '700', color: '#111827' },
  chipTextSelected: { color: '#fff' },
  exercise: { fontSize: 20, fontWeight: '800', marginBottom: 6 },
  detail: { fontSize: 15, marginBottom: 8 },
  note: { color: '#444', marginBottom: 8 },
  warmup: { color: '#666', fontSize: 13 },
});
