import React, { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import program from '../data/workoutProgram.json';
import { Card } from '../components/Card';
import { WeeklyCheckIn } from '../types/models';
import { loadWeeklyCheckIns, saveWeeklyCheckIns } from '../utils/storage';
import { targetWeightForWeek, weeklyLossFlag } from '../utils/calculations';

export function WeeklyCheckInScreen() {
  const [checkIns, setCheckIns] = useState<WeeklyCheckIn[]>([]);
  const [week, setWeek] = useState('1');
  const [actualWeight, setActualWeight] = useState('');
  const [waist, setWaist] = useState('');
  const [stepsAvg, setStepsAvg] = useState('');

  useEffect(() => { loadWeeklyCheckIns().then(setCheckIns); }, []);

  const save = async () => {
    const entry: WeeklyCheckIn = { week: Number(week), actualWeight, waist, stepsAvg, trainingCalAvg: '', restCalAvg: '', benchE1Rm: '', squatE1Rm: '', deadliftE1Rm: '' };
    const updated = [...checkIns.filter(c => c.week !== entry.week), entry].sort((a, b) => a.week - b.week);
    await saveWeeklyCheckIns(updated);
    setCheckIns(updated);
    Alert.alert('Check-in saved', `Week ${week} was saved.`);
  };

  const setup = program.setup as Record<string, number>;
  const target = targetWeightForWeek(setup.start_weight, setup.goal_weight, setup.program_weeks, Number(week));
  const prior = checkIns.filter(c => c.week < Number(week)).pop();
  const loss = prior && actualWeight ? Number(prior.actualWeight) - Number(actualWeight) : 0;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Card>
        <Text style={styles.title}>Weekly Check-In</Text>
        <Text style={styles.help}>Target for week {week}: {target} lb</Text>
        {loss ? <Text style={styles.help}>Loss pace: {loss.toFixed(1)} lb — {weeklyLossFlag(loss)}</Text> : null}
        <Field label="Week" value={week} onChangeText={setWeek} />
        <Field label="Actual Weight" value={actualWeight} onChangeText={setActualWeight} />
        <Field label="Waist" value={waist} onChangeText={setWaist} />
        <Field label="Average Steps" value={stepsAvg} onChangeText={setStepsAvg} />
        <Pressable style={styles.saveButton} onPress={save}><Text style={styles.saveText}>Save Check-In</Text></Pressable>
      </Card>

      <Text style={styles.historyTitle}>History</Text>
      {checkIns.map(c => <Card key={c.week}><Text style={styles.history}>Week {c.week}: {c.actualWeight || '-'} lb • Waist {c.waist || '-'} • Steps {c.stepsAvg || '-'}</Text></Card>)}
    </ScrollView>
  );
}

function Field({ label, value, onChangeText }: { label: string; value: string; onChangeText: (value: string) => void }) {
  return <View style={styles.field}><Text style={styles.label}>{label}</Text><TextInput style={styles.input} keyboardType="numeric" value={value} onChangeText={onChangeText} /></View>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f3f4f6' },
  content: { padding: 16 },
  title: { fontSize: 22, fontWeight: '800', marginBottom: 6 },
  help: { color: '#555', marginBottom: 10 },
  field: { marginBottom: 12 },
  label: { fontWeight: '700', marginBottom: 6 },
  input: { backgroundColor: '#f9fafb', borderWidth: 1, borderColor: '#d1d5db', borderRadius: 10, padding: 12 },
  saveButton: { backgroundColor: '#111827', padding: 16, borderRadius: 14, alignItems: 'center', marginTop: 8 },
  saveText: { color: '#fff', fontWeight: '800', fontSize: 16 },
  historyTitle: { fontSize: 18, fontWeight: '800', marginVertical: 10 },
  history: { fontSize: 15 },
});
