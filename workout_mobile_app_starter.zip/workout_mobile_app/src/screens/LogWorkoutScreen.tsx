import React, { useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import program from '../data/workoutProgram.json';
import { Card } from '../components/Card';
import { TrainingRow, WorkoutLogEntry, WorkoutSetLog } from '../types/models';
import { estimatedOneRepMax, totalVolume } from '../utils/calculations';
import { loadWorkoutLogs, saveWorkoutLogs } from '../utils/storage';

const plan = program.trainingPlan as TrainingRow[];

export function LogWorkoutScreen() {
  const [week, setWeek] = useState(1);
  const [day, setDay] = useState('Mon');
  const [logs, setLogs] = useState<Record<string, WorkoutSetLog[]>>({});

  const rows = useMemo(() => plan.filter(r => r.week === week && r.day === day), [week, day]);

  useEffect(() => {
    const initial: Record<string, WorkoutSetLog[]> = {};
    rows.forEach((row, index) => {
      const count = Number(row.sets) || 3;
      initial[`${row.exercise}-${index}`] = Array.from({ length: count }, () => ({ weight: String(row.targetWt ?? ''), reps: '', completed: false }));
    });
    setLogs(initial);
  }, [week, day]);

  const updateSet = (key: string, index: number, field: 'weight' | 'reps', value: string) => {
    setLogs(prev => ({
      ...prev,
      [key]: prev[key].map((set, i) => i === index ? { ...set, [field]: value, completed: true } : set),
    }));
  };

  const save = async () => {
    const existing = await loadWorkoutLogs();
    const today = new Date().toISOString();
    const newEntries: WorkoutLogEntry[] = rows.map((row, index) => ({
      id: `${today}-${week}-${day}-${row.exercise}-${index}`,
      date: today,
      week,
      day,
      exercise: row.exercise,
      targetWt: row.targetWt,
      sets: logs[`${row.exercise}-${index}`] ?? [],
      notes: row.progressionRule,
    }));
    await saveWorkoutLogs([...existing, ...newEntries]);
    Alert.alert('Workout saved', `${newEntries.length} exercises were saved to your local log.`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.filters}>
        <FlatList horizontal data={Array.from({ length: 12 }, (_, i) => i + 1)} keyExtractor={item => `week-${item}`} renderItem={({ item }) => <Chip label={`W${item}`} selected={item === week} onPress={() => setWeek(item)} />} />
        <View style={styles.days}>{['Mon', 'Wed', 'Fri'].map(d => <Chip key={d} label={d} selected={d === day} onPress={() => setDay(d)} />)}</View>
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        {rows.map((row, rowIndex) => {
          const key = `${row.exercise}-${rowIndex}`;
          const sets = logs[key] ?? [];
          const topSet = sets.reduce((best, s) => Number(s.weight) * Number(s.reps) > Number(best.weight) * Number(best.reps) ? s : best, { weight: '0', reps: '0', completed: false });
          return (
            <Card key={key}>
              <Text style={styles.exercise}>{row.exercise}</Text>
              <Text style={styles.detail}>Target: {row.targetWt} lb • Prescribed: {row.sets} x {row.reps}</Text>
              {sets.map((set, index) => (
                <View key={index} style={styles.setRow}>
                  <Text style={styles.setLabel}>Set {index + 1}</Text>
                  <TextInput style={styles.input} keyboardType="numeric" value={set.weight} onChangeText={value => updateSet(key, index, 'weight', value)} placeholder="Wt" />
                  <TextInput style={styles.input} keyboardType="numeric" value={set.reps} onChangeText={value => updateSet(key, index, 'reps', value)} placeholder="Reps" />
                </View>
              ))}
              <Text style={styles.summary}>Volume: {totalVolume(sets).toLocaleString()} lb • e1RM: {estimatedOneRepMax(Number(topSet.weight), Number(topSet.reps)) || '-'}</Text>
            </Card>
          );
        })}
        <Pressable style={styles.saveButton} onPress={save}><Text style={styles.saveText}>Save Workout</Text></Pressable>
      </ScrollView>
    </View>
  );
}

function Chip({ label, selected, onPress }: { label: string; selected: boolean; onPress: () => void }) {
  return <Pressable onPress={onPress} style={[styles.chip, selected && styles.chipSelected]}><Text style={[styles.chipText, selected && styles.chipTextSelected]}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f3f4f6' },
  filters: { padding: 12, backgroundColor: '#fff' },
  days: { flexDirection: 'row', marginTop: 10 },
  content: { padding: 16, paddingBottom: 32 },
  chip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 999, backgroundColor: '#e5e7eb', marginRight: 8 },
  chipSelected: { backgroundColor: '#111827' },
  chipText: { fontWeight: '700', color: '#111827' },
  chipTextSelected: { color: '#fff' },
  exercise: { fontSize: 19, fontWeight: '800', marginBottom: 4 },
  detail: { color: '#555', marginBottom: 10 },
  setRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  setLabel: { width: 52, fontWeight: '700' },
  input: { flex: 1, backgroundColor: '#f9fafb', borderWidth: 1, borderColor: '#d1d5db', borderRadius: 10, padding: 10 },
  summary: { marginTop: 6, fontWeight: '700' },
  saveButton: { backgroundColor: '#111827', padding: 16, borderRadius: 14, alignItems: 'center' },
  saveText: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
