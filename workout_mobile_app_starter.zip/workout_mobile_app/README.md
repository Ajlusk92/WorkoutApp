# Workout Program Mobile App

Cross-platform React Native / Expo starter app generated from `Workout_Program.xlsm`.

## What is included

- Dashboard for start weight, goal weight, weekly target, logged volume, and 1RM/training maxes
- 12-week training plan viewer filtered by week and Mon/Wed/Fri sessions
- Workout logger with set-by-set weight/reps, volume, and estimated 1RM
- Weekly check-in tracker for weight, waist, and steps
- Nutrition, mobility, and progression rule reference screens
- Local offline storage using `@react-native-async-storage/async-storage`

## Run it

```bash
npm install
npx expo install @react-native-async-storage/async-storage react-native-screens react-native-safe-area-context
npm start
```

Then scan the QR code with Expo Go or run:

```bash
npm run android
npm run ios
```

## File map

```text
App.tsx
src/data/workoutProgram.json       # Workbook data extracted from Excel
src/screens/DashboardScreen.tsx
src/screens/PlanScreen.tsx
src/screens/LogWorkoutScreen.tsx
src/screens/WeeklyCheckInScreen.tsx
src/screens/ReferenceScreen.tsx
src/utils/calculations.ts
src/utils/storage.ts
src/types/models.ts
```

## Next upgrades

- Add login/cloud sync with Supabase, Firebase, or SQLite sync
- Add charts for bodyweight trend and training volume
- Add push reminders for workout days and weekly check-ins
- Add exercise substitution and progressive overload recommendations
